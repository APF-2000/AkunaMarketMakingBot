import functools
import math
import random
from collections import defaultdict
from dataclasses import dataclass, replace
from enum import StrEnum
from statistics import NormalDist
from typing import Any, Final

AJARAI_NAME: Final[str] = "AJR"
AJARAI_UNDERLYING_ID: Final[int] = 2
FED_FUNDS_RATE_NAME: Final[str] = "FED"
FED_FUNDS_RATE_UNDERLYING_ID: Final[int] = 1
RATE_STRIKE_GRID: Final[float] = 0.25
THERIODIC_NAME: Final[str] = "THR"
THERIODIC_UNDERLYING_ID: Final[int] = 3
UNDERLYING_NAME_BY_ID: Final[dict[int, str]] = {
    AJARAI_UNDERLYING_ID: AJARAI_NAME,
    FED_FUNDS_RATE_UNDERLYING_ID: FED_FUNDS_RATE_NAME,
    THERIODIC_UNDERLYING_ID: THERIODIC_NAME,
}


@dataclass(eq=True, frozen=True, unsafe_hash=True)
class BinaryOption:
    legs: "tuple[OptionLeg, ...]"
    option_id: int
    steps_until_expiry: int
    strike: float

    def __post_init__(self) -> None:
        if self.steps_until_expiry < 0:
            raise ValueError("Steps until expiry must be non-negative")
        if not self.legs:
            raise ValueError("Binary option must have at least one leg")
        ids = [leg.underlying_id for leg in self.legs]
        if len(ids) != len(set(ids)):
            raise ValueError("Binary option legs must reference distinct underlyings")
        if any(leg.weight == 0 for leg in self.legs):
            raise ValueError("Binary option leg weights must be non-zero")

    def __str__(self) -> str:
        terms = []
        for index, leg in enumerate(self.legs):
            name = UNDERLYING_NAME_BY_ID.get(leg.underlying_id, str(leg.underlying_id))
            magnitude = abs(leg.weight)
            magnitude_str = "" if magnitude == 1 else f"{magnitude:.2f}*"
            sign = ("-" if leg.weight < 0 else "") if index == 0 else (
                " - " if leg.weight < 0 else " + "
            )
            terms.append(f"{sign}{magnitude_str}{name}")
        return f"{self.option_id} ({self.steps_until_expiry}d {''.join(terms)} >= {self.strike:.2f})"

    def advance_step(self) -> "BinaryOption":
        return self if self.steps_until_expiry == 0 else replace(
            self, steps_until_expiry=self.steps_until_expiry - 1
        )

    def contract_matches(self, other: "BinaryOption") -> bool:
        return replace(other, option_id=self.option_id) == self

    def expiry_valuation(self, value_by_underlying_id: dict[int, float]) -> float:
        return float(self.observable_value(value_by_underlying_id) >= self.strike)

    def observable_value(self, value_by_underlying_id: dict[int, float]) -> float:
        return sum(
            leg.weight * value_by_underlying_id[leg.underlying_id]
            for leg in self.legs
        )


@dataclass(frozen=True)
class FokOrder:
    counterparty_id: int
    option_id: int
    order_type: "OrderType"
    price: float
    quantity: int

    def __post_init__(self) -> None:
        if self.price < 0:
            raise ValueError("FOK order price must be non-negative")
        if self.quantity <= 0:
            raise ValueError("FOK order quantity must be positive")


@dataclass(frozen=True)
class MarketHistory:
    values_by_underlying_id: dict[int, tuple[float, ...]]

    def __post_init__(self) -> None:
        lengths = {len(values) for values in self.values_by_underlying_id.values()}
        if len(lengths) > 1:
            raise ValueError("All underlyings must have the same number of historical days")
        if lengths and next(iter(lengths)) <= 0:
            raise ValueError("Market history must contain at least one day")

    @property
    def num_days(self) -> int:
        return 0 if not self.values_by_underlying_id else len(
            next(iter(self.values_by_underlying_id.values()))
        )


@dataclass(frozen=True)
class MarketParameters:
    ajarai_drift: float
    ajarai_idio_std_dev: float
    ajarai_rate_beta: float
    ajarai_sector_beta: float
    rate_down_probability: float
    rate_reversion_strength: float
    rate_up_probability: float
    sector_std_dev: float
    theriodic_drift: float
    theriodic_idio_std_dev: float
    theriodic_rate_beta: float
    theriodic_sector_beta: float
    rate_step: float = 0.25
    rate_target: float = 2.0

    def __post_init__(self) -> None:
        if self.rate_step <= 0:
            raise ValueError("Rate step must be positive")
        if self.rate_up_probability <= 0 or self.rate_down_probability <= 0:
            raise ValueError("Rate up/down probabilities must both be positive")
        if self.rate_up_probability + self.rate_down_probability > 1:
            raise ValueError("Rate up/down probabilities must not sum to more than 1")
        if self.rate_target < 0:
            raise ValueError("Rate target must be non-negative")
        if not 0 <= self.rate_reversion_strength <= 1:
            raise ValueError("Rate reversion strength must be between 0 and 1")
        if min(self.ajarai_idio_std_dev, self.theriodic_idio_std_dev, self.sector_std_dev) < 0:
            raise ValueError("Standard deviations must be non-negative")

    def advance_company_value(self, current_value, rate_change, sector_shock, *,
                              drift, rate_beta, sector_beta, idio_std_dev):
        log_return = (drift + rate_beta * rate_change + sector_beta * sector_shock
                      + random.gauss(0.0, idio_std_dev))
        return round(current_value * math.exp(log_return), 2)

    def advance_rate(self, rate_value: float) -> float:
        up, down = self.tilted_rate_probabilities(rate_value)
        draw = random.random()
        if draw < up:
            return self.next_rate_value(rate_value, 1)
        if draw < up + down:
            return self.next_rate_value(rate_value, -1)
        return rate_value

    def advance_step(self, value_by_underlying_id: dict[int, float]) -> dict[int, float]:
        old_rate = value_by_underlying_id[FED_FUNDS_RATE_UNDERLYING_ID]
        rate = self.advance_rate(old_rate)
        change = round(rate - old_rate, 2)
        sector = random.gauss(0.0, self.sector_std_dev)
        return {
            FED_FUNDS_RATE_UNDERLYING_ID: rate,
            AJARAI_UNDERLYING_ID: self.advance_company_value(
                value_by_underlying_id[AJARAI_UNDERLYING_ID], change, sector,
                drift=self.ajarai_drift, rate_beta=self.ajarai_rate_beta,
                sector_beta=self.ajarai_sector_beta,
                idio_std_dev=self.ajarai_idio_std_dev),
            THERIODIC_UNDERLYING_ID: self.advance_company_value(
                value_by_underlying_id[THERIODIC_UNDERLYING_ID], change, sector,
                drift=self.theriodic_drift, rate_beta=self.theriodic_rate_beta,
                sector_beta=self.theriodic_sector_beta,
                idio_std_dev=self.theriodic_idio_std_dev),
        }

    def next_rate_value(self, rate_value: float, num_grid_steps: int) -> float:
        return max(round(rate_value + num_grid_steps * self.rate_step, 2), 0.0)

    def tilted_rate_probabilities(self, rate_value: float) -> tuple[float, float]:
        tilt = self.rate_reversion_strength * (self.rate_target - rate_value)
        up = min(max(self.rate_up_probability + tilt, 0.0), 1.0)
        down = min(max(self.rate_down_probability - tilt, 0.0), 1.0 - up)
        return up, down


@dataclass(frozen=True)
class OptionLeg:
    underlying_id: int
    weight: float


class OrderType(StrEnum):
    BUY = "buy"
    SELL = "sell"


class Position:
    def __init__(self) -> None:
        self.option_quantity_by_option_id: dict[int, int] = defaultdict(int)

    def add_option_quantity(self, option_id: int, quantity: int) -> None:
        self.option_quantity_by_option_id[option_id] += quantity


@dataclass(frozen=True)
class Quote:
    bid_price: float
    bid_quantity: int
    offer_price: float
    offer_quantity: int

    def __post_init__(self) -> None:
        if self.bid_quantity <= 0 or self.offer_quantity <= 0:
            raise ValueError("Quote quantities must be positive")
        if not (0 <= self.bid_price <= 1 and 0 <= self.offer_price <= 1):
            raise ValueError("Quote prices must be between 0 and 1")
        if self.bid_price >= self.offer_price:
            raise ValueError("Quote bid price must be less than offer price")
        if any(abs(round(p * 100) - p * 100) > 1e-6
               for p in (self.bid_price, self.offer_price)):
            raise ValueError("Quote prices must be in whole pennies (multiples of 0.01)")


@dataclass(frozen=True)
class Underlying:
    name: str
    underlying_id: int
    value: float

    def __eq__(self, other: Any) -> bool:
        return isinstance(other, Underlying) and self.underlying_id == other.underlying_id


class MarketMaker:
    TICK = 0.01
    EPS = 1e-12
    Z = 1.645
    ZERO_QTY = 100
    QUAD_LIVE = 64
    QUAD_THEO = 128

    def __init__(self, underlying_initial_state, option_initial_state, cash_balance):
        self.underlying_state = underlying_initial_state
        self.active_option_state = option_initial_state
        self.cash_balance = cash_balance
        self._initial_cash = cash_balance
        self.position = Position()
        self.estimated_market_parameters = None
        self._history = None
        self._n = 0
        self._pairs = []
        self._price_cache = {}
        self._bound_cache = {}
        # Posterior distribution of the effective rival best-quote cutoff on
        # each side.  A fill means cutoff >= our distance; a miss is the
        # hidden-side mixture of the two complementary censoring events.
        cutoff = self._initial_cutoff()
        self._cutoff_posterior = [cutoff[:], cutoff[:]]
        survival = self._survival_curve(cutoff)
        self._cutoff_survival = [survival, survival]
        self._side_counts = {}
        self._allocation_global = [defaultdict(float), defaultdict(float)]
        self._allocation_cp = {}
        self._size_global = [defaultdict(float), defaultdict(float)]
        self._size_cp = {}
        self._pending = {}
        self._fok_reserved = {}
        self._reserved_cash = 0.0
        self._reserved_cents = 0
        self._gross_long = defaultdict(int)
        self._gross_short = defaultdict(int)
        self._contracts = {}
        self._lots = []
        self._today_cache = None
        # Exact checker-shadow cash: fills subtract their maximum-loss debit
        # and expired lots add their realised checker credit, all in cents.
        self._safe_cash_cents = math.floor(cash_balance * 100.0 + self.EPS)
        self.cash_balance = self._safe_cash_cents / 100.0

    @property
    def name(self):
        return "Pipeline-Asymmetric Auction Kelly MM"

    def warm_up(self, market_history):
        ids = {FED_FUNDS_RATE_UNDERLYING_ID, AJARAI_UNDERLYING_ID,
               THERIODIC_UNDERLYING_ID}
        if ids - market_history.values_by_underlying_id.keys():
            raise ValueError("Market history is missing a required underlying")
        if market_history.num_days < 2:
            raise ValueError("At least two historical days are required")
        self._history = {uid: list(market_history.values_by_underlying_id[uid])
                         for uid in ids}
        self._fit_history()

    def on_step_advance(self, new_underlying_state, new_option_state):
        self._finish_requests()
        self._settle(new_underlying_state, new_option_state)
        if self._history is not None:
            new_values = {u.underlying_id: u.value for u in new_underlying_state}
            for uid in self._history:
                self._history[uid].append(new_values[uid])
            self._fit_history()
        self.underlying_state = new_underlying_state
        self.active_option_state = new_option_state
        self._clear_caches()

    def on_trade(self, option, price, quantity, counterparty_id):
        key = (counterparty_id, option.option_id)
        side = 0 if quantity > 0 else 1
        fkey = (counterparty_id, option.option_id, round(price, 8), side)
        # Reservations form a day-level collateral ledger.  A fill converts
        # reserved risk into an equal cash debit below; unfilled risk is never
        # released merely because another request has arrived.
        if fkey in self._fok_reserved:
            reservations = self._fok_reserved[fkey]
            _, reservation = reservations.pop()
            self._release_reservation(reservation)
            if not reservations:
                del self._fok_reserved[fkey]
        else:
            pending = self._pending.get(key)
            if pending:
                self._resolve_quote(key, side, abs(quantity))
        self.position.add_option_quantity(option.option_id, quantity)
        self._contracts[option.option_id] = option
        if quantity > 0:
            self._gross_long[option.option_id] += quantity
        else:
            self._gross_short[option.option_id] += -quantity
        self._lots.append([option, option.steps_until_expiry, quantity])
        self._today_cache = None
        self._safe_cash_cents -= self._loss_cents(
            price, 1 if quantity > 0 else -1, abs(quantity))
        self.cash_balance = self._safe_cash_cents / 100.0

    def price_option_from_parameters(self, market_parameters, option):
        values = self._current_values()
        self._validate(values, option)
        if option.steps_until_expiry == 0:
            return option.expiry_valuation(values)
        return self._price_core(market_parameters, option, values, self.QUAD_THEO)

    def price_option(self, option):
        if self.estimated_market_parameters is None:
            raise RuntimeError("warm_up must be called before live pricing")
        return self._live_price(option)

    def quote(self, option, counterparty_id):
        # Each callback belongs to one immediately routed RFQ/FOK.  Reaching a
        # new request proves that every preceding one-shot auction is complete.
        self._finish_requests()
        key = (counterparty_id, option.option_id)
        p, lo, hi = self._inventory_bounds(option)
        spendable = self._spendable()
        bid, bq, bk = self._choose_side(option, counterparty_id, 0, p, lo, spendable)
        ask, aq, ak = self._choose_side(option, counterparty_id, 1, p, hi, spendable)
        if bid >= ask:
            bid, ask, bq, aq, bk, ak = 0.0, 1.0, self.ZERO_QTY, self.ZERO_QTY, 100, 100
        reserve = max(self._reservation_cents(option, bid, 1, bq),
                      self._reservation_cents(option, ask, -1, aq))
        self._add_reservation(reserve)
        self._pending[key] = (bid, ask, bk, ak, reserve)
        return Quote(round(bid, 2), bq, round(ask, 2), aq)

    def respond_to_fok(self, option, fok_order):
        self._finish_requests()
        if fok_order.option_id != option.option_id:
            return False
        p = self._live_price(option)
        q, x = fok_order.quantity, fok_order.price
        wealth = self._spendable()
        if fok_order.order_type == OrderType.BUY:
            edge = x - p
            side = -1
            auction_side = 1
        else:
            edge = p - x
            side = 1
            auction_side = 0
        collateral = self._loss_cents(x, side, q)
        self._observe_known_side(fok_order.counterparty_id, auction_side)
        self._observe_order_size(fok_order.counterparty_id, auction_side, q)
        key = (fok_order.counterparty_id, option.option_id, round(x, 8), auction_side)
        if collateral == 0:
            # Buying at zero or selling at one-or-more is pathwise non-losing,
            # even when all ordinary cash has already been committed.
            self._fok_reserved.setdefault(key, []).append((q, 0.0))
            return True
        if edge <= 0 or self._cash_quantity(x, side, q, option) < q:
            return False
        optimal, _ = self._portfolio_kelly(option, x, p, side, wealth)
        optimal = min(optimal, self._cash_quantity(x, side, optimal, option))
        if q > optimal:
            return False
        if self._portfolio_log_gain(option, q, x, p, side, wealth) <= 0:
            return False
        reservation = self._reservation_cents(option, x, side, q)
        self._fok_reserved.setdefault(key, []).append((q, reservation))
        self._add_reservation(reservation)
        return True

    def _fit_history(self):
        rid, aid, tid = (FED_FUNDS_RATE_UNDERLYING_ID, AJARAI_UNDERLYING_ID,
                         THERIODIC_UNDERLYING_ID)
        rates, av, tv = self._history[rid], self._history[aid], self._history[tid]
        if min(av + tv) <= 0:
            raise ValueError("Company values must remain positive")
        changes = [round(b - a, 2) for a, b in zip(rates, rates[1:])]
        ar = [math.log(b / a) for a, b in zip(av, av[1:])]
        tr = [math.log(b / a) for a, b in zip(tv, tv[1:])]
        n = len(changes)
        weights = [1.0] * n
        up, down, kappa, target, step, rstats = self._fit_rate(rates, weights)
        ai, ab, ae, ax, adf = self._ols(changes, ar, weights)
        ti, tb, te, tx, tdf = self._ols(changes, tr, weights)
        df = max(min(adf, tdf), 1.0)
        # Two weak prior degrees of freedom prevent a one- or two-move warm-up
        # from falsely implying deterministic company values.  The prior is
        # negligible once a normal-sized history has arrived.
        prior_df, prior_variance = 2.0, 0.03 ** 2
        denominator = df + prior_df
        va = max((sum(w * x * x for w, x in zip(weights, ae)) + prior_df * prior_variance)
                 / denominator, 1e-12)
        vt = max((sum(w * x * x for w, x in zip(weights, te)) + prior_df * prior_variance)
                 / denominator, 1e-12)
        cov = sum(w * x * y for w, x, y in zip(weights, ae, te)) / denominator
        cov = min(max(cov, -math.sqrt(va * vt)), math.sqrt(va * vt))
        sa, st, ia, it = self._factorize(va, vt, cov)
        central = MarketParameters(
            ai, ia, ab, sa, down, kappa, up, 1.0,
            ti, it, tb, st, step, target)
        self.estimated_market_parameters = central
        self._n = n
        self._pairs = self._uncertainty_pairs(
            central, rstats, (va, vt, cov), ax, tx, df)
        self._clear_caches()

    @classmethod
    def _fit_rate(cls, rates, weights):
        observations = list(zip(rates, rates[1:]))
        n = len(observations)
        state_counts = defaultdict(lambda: [0, 0, 0])
        for (rate, nxt), weight in zip(observations, weights):
            outcome = 0 if nxt > rate + 1e-8 else 1 if nxt < rate - 1e-8 else 2
            state_counts[rate][outcome] += weight
        counts = defaultdict(float)
        for (a, b), weight in zip(observations, weights):
            if abs(b - a) > 1e-8:
                counts[round(abs(b - a), 2)] += weight
        if counts:
            step = max(counts, key=counts.get)
        else:
            step = RATE_STRIKE_GRID
        sw = sum(weights)
        target = max(sum(w * a for w, (a, _) in zip(weights, observations)) / sw, 0.0)
        nu = sum(w for w, (a, b) in zip(weights, observations) if b > a + 1e-8)
        nd = sum(w for w, (a, b) in zip(weights, observations) if b < a - 1e-8)
        u0 = (nu + 0.5) / (sw + 1.5)
        d0 = (nd + 0.5) / (sw + 1.5)
        scale = min(0.98 / max(u0 + d0, cls.EPS), 1.0)
        u0, d0 = u0 * scale, d0 * scale

        def project(x):
            u = min(max(x[0], 1e-5), 0.99998)
            d = min(max(x[1], 1e-5), 0.99999 - u)
            return [u, d, min(max(x[2], 0.0), 1.0)]

        def score(x):
            u0x, d0x, k = x
            value = 0.25 * (math.log(u0x) + math.log(d0x)
                            + math.log(max(1.0 - u0x - d0x, 1e-8)))
            for r, (num_up, num_down, num_stay) in state_counts.items():
                tilt = k * (target - r)
                u = min(max(u0x + tilt, 0.0), 1.0)
                d = min(max(d0x - tilt, 0.0), 1.0 - u)
                stay = 1.0 - u if r <= 1e-8 else 1.0 - u - d
                value += (num_up * math.log(max(u, 1e-12))
                          + num_down * math.log(max(d, 1e-12))
                          + num_stay * math.log(max(stay, 1e-12)))
            return value

        best, best_score = None, -math.inf
        for start_k in (0.0, 0.02, 0.05, 0.1, 0.2, 0.4, 0.7, 1.0):
            x = project([u0, d0, start_k])
            value = score(x)
            steps = [0.12, 0.12, 0.12]
            for _ in range(70):
                changed = False
                for j in range(3):
                    for direction in (-1, 1):
                        candidate = project([v + (direction * steps[j] if i == j else 0)
                                             for i, v in enumerate(x)])
                        candidate_value = score(candidate)
                        if candidate_value > value + 1e-10:
                            x, value, changed = candidate, candidate_value, True
                if not changed:
                    steps = [s * 0.55 for s in steps]
                    if max(steps) < 2e-5:
                        break
            if value > best_score:
                best, best_score = x, value
        u, d, kappa = best
        spread = sum(w * (r - target) ** 2 for w, (r, _) in zip(weights, observations))
        effective_n = sw * sw / sum(w * w for w in weights)
        se_u = math.sqrt(max(u * (1 - u), 1e-5) / (effective_n + 1.5))
        se_d = math.sqrt(max(d * (1 - d), 1e-5) / (effective_n + 1.5))
        se_k = min(0.5, 1.0 / math.sqrt(spread + 4.0))
        return u, d, kappa, target, step, (se_u, se_d, se_k)

    @classmethod
    def _ols(cls, x, y, weights):
        sw = sum(weights)
        xm = sum(w * v for w, v in zip(weights, x)) / sw
        ym = sum(w * v for w, v in zip(weights, y)) / sw
        sxx = sum(w * (v - xm) ** 2 for w, v in zip(weights, x))
        if sxx <= cls.EPS:
            intercept, slope = ym, 0.0
            intercept_coefficients = [w / sw for w in weights]
            inv = (sum(v * v for v in intercept_coefficients), 0.0,
                   1.0 / max(sum(w * v * v for w, v in zip(weights, x)), 1e-4))
            trace = sum(w * c for w, c in zip(weights, intercept_coefficients))
        else:
            slope = sum(w * (a - xm) * (b - ym)
                        for w, a, b in zip(weights, x, y)) / sxx
            intercept = ym - slope * xm
            slope_coefficients = [w * (v - xm) / sxx for w, v in zip(weights, x)]
            intercept_coefficients = [w / sw - xm * c
                                      for w, c in zip(weights, slope_coefficients)]
            inv = (sum(c * c for c in intercept_coefficients), 0.0,
                   sum(c * c for c in slope_coefficients))
            trace = sum(w * (a + v * b) for w, v, a, b in
                        zip(weights, x, intercept_coefficients, slope_coefficients))
        residuals = [b - intercept - slope * a for a, b in zip(x, y)]
        return intercept, slope, residuals, inv, max(sw - trace, 1.0)

    @classmethod
    def _factorize(cls, va, vt, cov):
        if va <= cls.EPS or vt <= cls.EPS:
            return 0.0, 0.0, math.sqrt(max(va, 0)), math.sqrt(max(vt, 0))
        rho = min(max(cov / math.sqrt(va * vt), -0.999999), 0.999999)
        sa = math.sqrt(abs(rho) * va)
        st = math.copysign(math.sqrt(abs(rho) * vt), rho)
        return sa, st, math.sqrt(max(va - sa * sa, 0)), math.sqrt(max(vt - st * st, 0))

    def _uncertainty_pairs(self, p, rstats, covariance, ax, tx, df):
        pairs = []

        def rate_pair(field, se):
            plus = self._safe_rate_replace(p, field, getattr(p, field) + se)
            minus = self._safe_rate_replace(p, field, getattr(p, field) - se)
            pairs.append((plus, minus))

        rate_pair("rate_up_probability", rstats[0])
        rate_pair("rate_down_probability", rstats[1])
        rate_pair("rate_reversion_strength", rstats[2])
        va, vt, cov = covariance
        for prefix, variance, inv in (("ajarai", va, ax), ("theriodic", vt, tx)):
            sd_i = math.sqrt(max(variance * inv[0], 0.0))
            sd_b = math.sqrt(max(variance * inv[2], 0.0))
            pairs.append((replace(p, **{prefix + "_drift": getattr(p, prefix + "_drift") + sd_i}),
                          replace(p, **{prefix + "_drift": getattr(p, prefix + "_drift") - sd_i})))
            pairs.append((replace(p, **{prefix + "_rate_beta": getattr(p, prefix + "_rate_beta") + sd_b}),
                          replace(p, **{prefix + "_rate_beta": getattr(p, prefix + "_rate_beta") - sd_b})))
        scale = math.exp(min(0.7, 1.0 / math.sqrt(max(2 * df, 1))))
        pairs.append((self._with_covariance(p, va * scale * scale, vt * scale * scale,
                                            cov * scale * scale),
                      self._with_covariance(p, va / (scale * scale), vt / (scale * scale),
                                            cov / (scale * scale))))
        if df > 3 and va * vt > self.EPS:
            rho = min(max(cov / math.sqrt(va * vt), -0.999), 0.999)
            zr = math.atanh(rho)
            se = 1.0 / math.sqrt(df - 2)
            rp, rm = math.tanh(zr + se), math.tanh(zr - se)
            pairs.append((self._with_covariance(p, va, vt, rp * math.sqrt(va * vt)),
                          self._with_covariance(p, va, vt, rm * math.sqrt(va * vt))))
        return pairs

    @classmethod
    def _safe_rate_replace(cls, p, field, value):
        values = {"rate_up_probability": p.rate_up_probability,
                  "rate_down_probability": p.rate_down_probability,
                  "rate_reversion_strength": p.rate_reversion_strength}
        values[field] = value
        values["rate_reversion_strength"] = min(max(values["rate_reversion_strength"], 0), 1)
        values["rate_up_probability"] = min(max(values["rate_up_probability"], 1e-5), 0.99998)
        values["rate_down_probability"] = min(max(values["rate_down_probability"], 1e-5),
                                               0.99999 - values["rate_up_probability"])
        return replace(p, **values)

    @classmethod
    def _with_covariance(cls, p, va, vt, cov):
        sa, st, ia, it = cls._factorize(max(va, 1e-12), max(vt, 1e-12), cov)
        return replace(p, ajarai_sector_beta=sa, theriodic_sector_beta=st,
                       ajarai_idio_std_dev=ia, theriodic_idio_std_dev=it,
                       sector_std_dev=1.0)

    def _live_price(self, option):
        key = (self.estimated_market_parameters, option, self._relevant_values(option))
        if key not in self._price_cache:
            values = self._current_values()
            if option.steps_until_expiry == 0:
                price = option.expiry_valuation(values)
            else:
                price = self._price_core(self.estimated_market_parameters, option,
                                         values, self.QUAD_LIVE)
            self._price_cache[key] = price
        return self._price_cache[key]

    def _price_bounds(self, option):
        key = (option, self._relevant_values(option))
        if key in self._bound_cache:
            return self._bound_cache[key]
        p = self._live_price(option)
        if option.steps_until_expiry == 0:
            result = (p, p, p)
        else:
            values = self._current_values()
            variance = 0.0
            for plus, minus in self._pairs:
                pp = self._price_core(plus, option, values, self.QUAD_LIVE)
                pm = self._price_core(minus, option, values, self.QUAD_LIVE)
                variance += ((pp - pm) * 0.5) ** 2
            # Live quotes are penny-valued, so use a fixed conservative allowance
            # for the omitted sub-penny rounding correction and 64-point integral.
            uncertainty = self.Z * math.sqrt(variance) + 0.003
            result = (p, max(0.0, p - uncertainty), min(1.0, p + uncertainty))
        self._bound_cache[key] = result
        return result

    @classmethod
    def _price_core(cls, p, option, values, points):
        if option.steps_until_expiry == 0:
            return option.expiry_valuation(values)
        weights = {leg.underlying_id: leg.weight for leg in option.legs}
        rw = weights.get(FED_FUNDS_RATE_UNDERLYING_ID, 0.0)
        aw = weights.get(AJARAI_UNDERLYING_ID, 0.0)
        tw = weights.get(THERIODIC_UNDERLYING_ID, 0.0)
        r0 = values[FED_FUNDS_RATE_UNDERLYING_ID]
        rate_key = (p.rate_up_probability, p.rate_down_probability,
                    p.rate_reversion_strength, p.rate_target, p.rate_step)
        distribution = cls._rate_distribution(rate_key, r0,
                                               option.steps_until_expiry)
        if aw == 0 and tw == 0:
            return sum(prob for r, prob in distribution.items()
                       if rw * r >= option.strike - 1e-12 * max(1.0, abs(option.strike)))
        h = option.steps_until_expiry
        am = math.log(values[AJARAI_UNDERLYING_ID]) + h * p.ajarai_drift if aw else 0.0
        tm = math.log(values[THERIODIC_UNDERLYING_ID]) + h * p.theriodic_drift if tw else 0.0
        av = h * ((p.ajarai_sector_beta * p.sector_std_dev) ** 2
                  + p.ajarai_idio_std_dev ** 2) if aw else 0.0
        tv = h * ((p.theriodic_sector_beta * p.sector_std_dev) ** 2
                  + p.theriodic_idio_std_dev ** 2) if tw else 0.0
        ast, tst = math.sqrt(av), math.sqrt(tv)
        corr = 0.0
        if ast > cls.EPS and tst > cls.EPS:
            corr = h * p.ajarai_sector_beta * p.theriodic_sector_beta * p.sector_std_dev ** 2 / (ast * tst)
            corr = min(max(corr, -1.0), 1.0)
        total = 0.0
        for rate, probability in distribution.items():
            strike = option.strike - rw * rate
            ma = am + p.ajarai_rate_beta * (rate - r0) if aw else 0.0
            mt = tm + p.theriodic_rate_beta * (rate - r0) if tw else 0.0
            if aw and tw:
                cp = cls._two_company_probability(aw, ma, ast, tw, mt, tst,
                                                  corr, strike, points)
            elif aw:
                cp = cls._weighted_lognormal_probability(aw, ma, ast, strike)
            else:
                cp = cls._weighted_lognormal_probability(tw, mt, tst, strike)
            total += probability * cp
        return min(max(total, 0.0), 1.0)

    @staticmethod
    @functools.cache
    def _rate_distribution(rate_key, initial, steps):
        up_base, down_base, reversion, target, step = rate_key
        dist = {initial: 1.0}
        for _ in range(steps):
            nxt = defaultdict(float)
            for rate, state_probability in dist.items():
                tilt = reversion * (target - rate)
                up = min(max(up_base + tilt, 0.0), 1.0)
                down = min(max(down_base - tilt, 0.0), 1.0 - up)
                nxt[max(round(rate + step, 2), 0.0)] += state_probability * up
                nxt[max(round(rate - step, 2), 0.0)] += state_probability * down
                nxt[rate] += state_probability * (1.0 - up - down)
            dist = dict(nxt)
        return dist

    @classmethod
    def _weighted_lognormal_probability(cls, weight, mean, sd, strike):
        if sd <= cls.EPS:
            value = weight * math.exp(mean)
            tolerance = 1e-12 * max(1.0, abs(value), abs(strike))
            return float(value >= strike - tolerance)
        if weight > 0:
            if strike <= 0:
                return 1.0
            z = (math.log(strike / weight) - mean) / sd
            return 0.5 * math.erfc(z / math.sqrt(2.0))
        threshold = strike / weight
        if threshold <= 0:
            return 0.0
        z = (math.log(threshold) - mean) / sd
        return 0.5 * math.erfc(-z / math.sqrt(2.0))

    @classmethod
    def _two_company_probability(cls, aw, am, ast, tw, tm, tst,
                                 correlation, strike, points):
        if ast <= cls.EPS:
            return cls._weighted_lognormal_probability(
                tw, tm, tst, strike - aw * math.exp(am))
        if tst <= cls.EPS:
            return cls._weighted_lognormal_probability(
                aw, am, ast, strike - tw * math.exp(tm))
        if abs(strike) <= cls.EPS and aw * tw < 0:
            if aw > 0:
                threshold = -tw / aw
                mean, variance = am - tm, ast * ast + tst * tst - 2 * correlation * ast * tst
            else:
                threshold = -aw / tw
                mean, variance = tm - am, ast * ast + tst * tst - 2 * correlation * ast * tst
            if variance <= cls.EPS:
                boundary = math.log(threshold)
                return float(mean >= boundary - 1e-12 * max(1.0, abs(boundary)))
            z = (mean - math.log(threshold)) / math.sqrt(variance)
            return 0.5 * math.erfc(-z / math.sqrt(2.0))
        conditional_sd = tst * math.sqrt(max(1.0 - correlation * correlation, 0.0))
        total = 0.0
        for z in cls._normal_points(points):
            first = math.exp(am + ast * z)
            conditional_mean = tm + correlation * tst * z
            total += cls._weighted_lognormal_probability(
                tw, conditional_mean, conditional_sd, strike - aw * first)
        return total / points

    @staticmethod
    @functools.cache
    def _normal_points(points):
        normal = NormalDist()
        return tuple(normal.inv_cdf((i + 0.5) / points) for i in range(points))

    def _inventory_bounds(self, option):
        # Inventory enters the robust two-state Kelly objective below.  Shifting
        # fair value here as well would count the same exposure twice.
        return self._price_bounds(option)

    def _choose_side(self, option, counterparty, side, fair, bound, wealth):
        best = None
        sign = 1 if side == 0 else -1
        # Select the penny using the cheap two-state objective, then solve the
        # full ladder exactly once at that executable price.  Re-solving a
        # many-state Kelly problem at all 100 ticks is unnecessary for the
        # inventory-sizing improvement and scales poorly with a dense chain.
        context = self._simple_context(option, bound, wealth)
        prices = range(0, 100) if side == 0 else range(1, 101)
        for tick in prices:
            price = tick / 100
            edge = bound - price if side == 0 else price - bound
            if edge <= self.EPS:
                continue
            demand_tick = min(max(round((fair - price if side == 0 else price - fair) * 100), 0), 100)
            probability = self._fill_probability(side, demand_tick)
            quantity, gain = self._portfolio_kelly_from_context(
                context, price, sign, wealth)
            quantity = min(quantity, self._cash_quantity(
                price, sign, quantity, option))
            gain = self._portfolio_gain_from_context(
                context, quantity, price, sign)
            gain = self._allocation_gain(context, price, sign, quantity,
                                         counterparty, side, gain)
            score = probability * gain
            if best is None or score > best[0]:
                best = (score, price, quantity, demand_tick)
        if best is None or best[0] <= 0:
            return (0.0, self.ZERO_QTY, 100) if side == 0 else (1.0, self.ZERO_QTY, 100)
        quantity, gain = self._portfolio_kelly(option, best[1], bound,
                                                sign, wealth)
        quantity = min(quantity, self._cash_quantity(
            best[1], sign, quantity, option))
        gain = self._portfolio_log_gain(
            option, quantity, best[1], bound, sign, wealth)
        if quantity <= 0 or gain <= 0:
            return (0.0, self.ZERO_QTY, 100) if side == 0 else (1.0, self.ZERO_QTY, 100)
        return best[1], quantity, best[3]

    def _simple_context(self, option, probability, wealth):
        active = {o.option_id: o for o in self.active_option_state}
        long = short = guaranteed = 0
        for oid in set(self._gross_long) | set(self._gross_short):
            held = active.get(oid)
            if held is None:
                continue
            if held.contract_matches(option):
                long += self._gross_long[oid]
                short += self._gross_short[oid]
            else:
                guaranteed += min(self._gross_long[oid], self._gross_short[oid])
        return ((wealth + guaranteed + long, wealth + guaranteed + short),
                (1.0, 0.0), (probability, 1.0 - probability))

    def _kelly_context(self, option, probability, wealth):
        """Exact terminal wealth states for nested same-expiry contracts."""
        active = {o.option_id: o for o in self.active_option_state}
        relevant = [(oid, active[oid]) for oid in set(self._gross_long) | set(self._gross_short)
                    if oid in active and (self._gross_long[oid] or self._gross_short[oid])]
        vector, candidate_strike = self._ladder_key(option)
        eligible = []
        guaranteed = 0
        for oid, held in relevant:
            held_vector, held_strike = self._ladder_key(held)
            if (held.steps_until_expiry == option.steps_until_expiry
                    and held_vector == vector):
                eligible.append((oid, held, held_strike))
            else:
                guaranteed += min(self._gross_long[oid], self._gross_short[oid])
        if not eligible:
            return ((wealth, wealth), (1.0, 0.0),
                    (probability, 1.0 - probability))

        # Every contract is an event {Y >= strike}; marginal probabilities
        # therefore determine the complete joint distribution of the ladder.
        representatives = {candidate_strike: option}
        representatives.update({strike: held for _, held, strike in eligible})
        strikes = sorted(representatives)
        survival = []
        previous = 1.0
        for strike in strikes:
            value = min(max(self._live_price(representatives[strike]), 0.0), previous)
            survival.append(value)
            previous = value
        masses = [1.0 - survival[0]]
        masses.extend(max(a - b, 0.0) for a, b in zip(survival, survival[1:]))
        masses.append(survival[-1])
        candidate_index = strikes.index(candidate_strike)

        states = []
        central = 0.0
        for reached, mass in enumerate(masses):
            if mass <= self.EPS:
                continue
            candidate_payoff = float(reached > candidate_index)
            credit = 0.0
            for oid, _, strike in eligible:
                payoff = reached > strikes.index(strike)
                credit += (self._gross_long[oid] * payoff
                           + self._gross_short[oid] * (1.0 - payoff))
            states.append([wealth + guaranteed + credit,
                           candidate_payoff, mass])
            central += mass * candidate_payoff

        # Preserve exact conditional ladder shape while moving the candidate's
        # total event probability to the requested robust side probability.
        if self.EPS < central < 1.0 - self.EPS:
            for state in states:
                state[2] *= (probability / central if state[1]
                             else (1.0 - probability) / (1.0 - central))
        return (tuple(state[0] for state in states),
                tuple(state[1] for state in states),
                tuple(state[2] for state in states))

    @staticmethod
    def _ladder_key(option):
        scale = math.sqrt(sum(leg.weight * leg.weight for leg in option.legs))
        vector = tuple((leg.underlying_id, round(leg.weight / scale, 12))
                       for leg in sorted(option.legs,
                                         key=lambda item: item.underlying_id))
        return vector, round(option.strike / scale, 12)

    @classmethod
    def _portfolio_gain_from_context(cls, context, quantity, price, sign):
        base, payoff, weights = context
        gain = 0.0
        for w, b, x in zip(weights, base, payoff):
            if w <= cls.EPS:
                continue
            # Log-wealth utility is undefined when the pre-trade scenario
            # wealth is non-positive.  Such a context is not an executable
            # Kelly comparison; reject it instead of entering log1p's domain.
            if b <= cls.EPS:
                return -math.inf
            change = quantity * (x - price) * sign
            if b + change <= cls.EPS:
                return -math.inf
            gain += w * math.log1p(change / b)
        return gain

    @classmethod
    def _portfolio_kelly_from_context(cls, context, price, sign, wealth):
        base, payoff, weights = context
        # This check must precede the zero-collateral shortcut.  A risk-free
        # payoff can make a negative terminal value positive, but the change
        # in log wealth is still undefined because the baseline log does not
        # exist.  Boundary quotes remain available through the safe fallback.
        if any(w > cls.EPS and b <= cls.EPS
               for w, b in zip(weights, base)):
            return 0, -math.inf
        loss = price if sign > 0 else 1.0 - price
        if loss <= cls.EPS:
            q = cls.ZERO_QTY  # Positive edge with zero collateral has no finite optimum.
            return q, cls._portfolio_gain_from_context(context, q, price, sign)
        # Log utility requires positive terminal wealth in every state with
        # non-zero probability.  Existing inventory makes the limiting wealth
        # state-dependent, so a scalar cash/loss cap is not the Kelly domain.
        # Compute the exact domain from the scenario wealths instead.
        cap = None
        for w, b, x in zip(weights, base, payoff):
            if w <= cls.EPS:
                continue
            y = (x - price) * sign
            if y < -cls.EPS:
                limit = max(0, math.floor(math.nextafter(b, 0.0) / -y))
                while limit and b + limit * y <= cls.EPS:
                    limit -= 1
                cap = limit if cap is None else min(cap, limit)
        if cap is None:
            cap = cls.ZERO_QTY
        if cap == 0:
            return 0, -math.inf

        # Exact closed form for a binary event when existing terminal wealth is
        # deterministic conditional on that event.  This includes the common
        # cases of empty inventory and inventory in the same contract.
        if len(base) == 2 and payoff == (1.0, 0.0):
            b1, b0 = base
            p = weights[0]
            y1, y0 = (1.0 - price) * sign, -price * sign
            numerator = p * y1 * b0 + (1.0 - p) * y0 * b1
            if numerator <= cls.EPS:
                return 0, 0.0
            root = -numerator / (y1 * y0)
            candidates = {min(cap, max(0, math.floor(root))),
                          min(cap, max(0, math.ceil(root)))}
            return max(((q, cls._portfolio_gain_from_context(context, q, price, sign))
                        for q in candidates), key=lambda item: item[1])

        def derivative(q):
            total = 0.0
            for w, b, x in zip(weights, base, payoff):
                y = (x - price) * sign
                denominator = b + q * y
                if denominator <= cls.EPS:
                    return -math.inf
                total += w * y / denominator
            return total

        if derivative(0.0) <= cls.EPS:
            return 0, 0.0
        lo, hi = 0, cap
        if derivative(hi) < 0.0:
            # The continuous objective is concave, and the executable quantity
            # is integral.  Locate the derivative sign change on the integer
            # lattice; the discrete optimum must be one of the adjacent points.
            while hi - lo > 1:
                mid = (lo + hi) // 2
                if derivative(mid) > 0.0:
                    lo = mid
                else:
                    hi = mid
            candidates = {lo, hi}
        else:
            candidates = {cap}
        quantity, gain = max(
            ((q, cls._portfolio_gain_from_context(context, q, price, sign))
             for q in candidates), key=lambda item: item[1])
        return quantity, gain

    def _portfolio_kelly(self, option, price, probability, sign, wealth):
        return self._portfolio_kelly_from_context(
            self._kelly_context(option, probability, wealth), price, sign, wealth)

    def _portfolio_log_gain(self, option, quantity, price, probability, sign, wealth):
        return self._portfolio_gain_from_context(
            self._kelly_context(option, probability, wealth), quantity, price, sign)

    def _fill_probability(self, side, tick):
        """Posterior allocation chance against the rival best-quote auction.

        The geometric cold start reproduces the baseline tight-market prior.
        Thereafter this is an actual posterior survival probability for the
        effective rival cutoff, not a counterparty reservation curve.
        """
        # Index zero is the explicit "no allocation even at distance zero"
        # state; cutoff t is stored at index t + 1.
        return self._cutoff_survival[side][tick + 1]

    @staticmethod
    def _initial_cutoff():
        survival = math.exp(-0.30)
        outside = math.ulp(1.0)
        scale = 1.0 - outside
        masses = [outside]
        masses.extend(scale * (1.0 - survival) * survival ** tick
                      for tick in range(100))
        masses.append(scale * survival ** 100)
        return masses

    @staticmethod
    def _survival_curve(masses):
        total = 0.0
        result = []
        for mass in reversed(masses):
            total += mass
            result.append(total)
        return tuple(reversed(result))

    def _allocation_gain(self, context, price, sign, quantity, counterparty,
                         side, full_gain):
        cp = self._allocation_cp.get(counterparty)
        histogram = cp[side] if cp and cp[side] else self._allocation_global[side]
        if not histogram:
            cp = self._size_cp.get(counterparty)
            histogram = cp[side] if cp and cp[side] else self._size_global[side]
        if not histogram:
            return full_gain
        total = sum(histogram.values())
        return sum(weight * self._portfolio_gain_from_context(
            context, min(quantity, observed), price, sign)
                   for observed, weight in histogram.items()) / total

    def _side_probability(self, counterparty):
        counts = self._side_counts.get(counterparty)
        if counts is None:
            return 0.5
        return counts[0] / (counts[0] + counts[1])

    def _observe_known_side(self, counterparty, side, weight=1.0):
        counts = self._side_counts.setdefault(counterparty, [0.5, 0.5])
        counts[side] += weight

    def _observe_order_size(self, counterparty, side, quantity):
        self._size_global[side][quantity] += 1.0
        curves = self._size_cp.setdefault(
            counterparty, [defaultdict(float), defaultdict(float)])
        curves[side][quantity] += 1.0

    def _record_allocation(self, counterparty, side, quantity):
        self._allocation_global[side][quantity] += 1.0
        curves = self._allocation_cp.setdefault(
            counterparty, [defaultdict(float), defaultdict(float)])
        curves[side][quantity] += 1.0

    def _condition_cutoff(self, side, tick, filled, responsibility=1.0):
        if responsibility <= self.EPS:
            return
        prior = self._cutoff_posterior[side]
        compatible = [value if ((index - 1 >= tick) == filled) else 0.0
                      for index, value in enumerate(prior)]
        probability = sum(compatible)
        if probability <= self.EPS:
            # An impossible observation proves that the effective rival quote
            # changed.  Restart that side from the cold-start distribution and
            # condition on the new observation; no change-rate is guessed.
            prior = self._initial_cutoff()
            compatible = [value if ((index - 1 >= tick) == filled) else 0.0
                          for index, value in enumerate(prior)]
            probability = sum(compatible)
            if probability == 0.0:
                return
        conditioned = [value / probability for value in compatible]
        # With a latent RFQ direction the exact marginal posterior is a
        # mixture of the unchanged prior and the side-conditioned posterior.
        posterior = [
            (1.0 - responsibility) * old + responsibility * new
            for old, new in zip(prior, conditioned)]
        self._cutoff_posterior[side] = posterior
        self._cutoff_survival[side] = self._survival_curve(posterior)

    def _resolve_quote(self, key, hit, quantity=0):
        pending = self._pending.pop(key, None)
        if pending is None:
            return
        _, _, bid_tick, ask_tick, reserve = pending
        self._release_reservation(reserve)
        counterparty = key[0]
        if hit == 0:
            self._observe_known_side(counterparty, 0)
            self._condition_cutoff(0, bid_tick, True)
            self._record_allocation(counterparty, 0, quantity)
        elif hit == 1:
            self._observe_known_side(counterparty, 1)
            self._condition_cutoff(1, ask_tick, True)
            self._record_allocation(counterparty, 1, quantity)
        else:
            sell_probability = self._side_probability(counterparty)
            bid_miss = 1.0 - self._fill_probability(0, bid_tick)
            ask_miss = 1.0 - self._fill_probability(1, ask_tick)
            denominator = (sell_probability * bid_miss
                           + (1.0 - sell_probability) * ask_miss)
            responsibility = (sell_probability if denominator <= self.EPS else
                              sell_probability * bid_miss / denominator)
            self._observe_known_side(counterparty, 0, responsibility)
            self._observe_known_side(counterparty, 1, 1.0 - responsibility)
            self._condition_cutoff(0, bid_tick, False, responsibility)
            self._condition_cutoff(1, ask_tick, False, 1.0 - responsibility)

    def _finish_requests(self):
        for key in list(self._pending):
            self._resolve_quote(key, -1)
        self._fok_reserved.clear()
        # The step boundary is the first protocol event proving that every
        # order from the preceding day can no longer allocate.
        self._reserved_cents = 0
        self._reserved_cash = 0.0

    def _settle(self, new_underlying_state, new_option_state):
        # Before this boundary only the payoff minimum was spendable.  The new
        # underlying state now fixes every expiring payoff, and the checker
        # credits that exact amount before its bankruptcy test.  Recycling the
        # realised credit here is therefore exact rather than model-dependent.
        expiring = [lot for lot in self._lots if lot[1] <= 1]
        values = {u.underlying_id: u.value for u in new_underlying_state}
        realised_credit = 0
        for option, _, quantity in expiring:
            payoff = option.expiry_valuation(values)
            realised_credit += abs(quantity) * 100 * (
                payoff if quantity > 0 else 1.0 - payoff)
        self._safe_cash_cents += int(realised_credit)
        survivors = []
        expired_ids = set()
        for option, remaining, quantity in self._lots:
            remaining -= 1
            if remaining > 0:
                survivors.append([option, remaining, quantity])
                continue
            oid = option.option_id
            self.position.add_option_quantity(oid, -quantity)
            if quantity > 0:
                self._gross_long[oid] -= quantity
            else:
                self._gross_short[oid] += quantity
            expired_ids.add(oid)
        self._lots = survivors
        self._today_cache = None
        self.cash_balance = self._safe_cash_cents / 100.0
        live_ids = {option.option_id for option, _, _ in survivors}
        for oid in expired_ids - live_ids:
            self.position.option_quantity_by_option_id.pop(oid, None)
            self._gross_long.pop(oid, None)
            self._gross_short.pop(oid, None)
            self._contracts.pop(oid, None)

    def _spendable(self):
        # This is the cash component of terminal wealth, not the safety limit.
        # It may be temporarily negative when a next-boundary payoff is already
        # pathwise guaranteed; inventory credits are added by the Kelly context.
        return (self._safe_cash_cents - self._reserved_cents) / 100.0

    def _free_cents(self):
        # Exact slack in the checker's next end-of-day solvency inequality.
        return max(self._safe_cash_cents + self._guaranteed_today_cents()
                   - self._reserved_cents, 0)

    @staticmethod
    def _contract_key(option):
        return (option.strike, tuple(sorted(
            (leg.underlying_id, leg.weight) for leg in option.legs)))

    def _today_group(self, option):
        """Long/short quantities in the same event credited next boundary."""
        if option.steps_until_expiry > 1:
            return 0, 0
        return self._today_groups()[0].get(self._contract_key(option), (0, 0))

    def _today_groups(self):
        if self._today_cache is None:
            groups = {}
            for option, remaining, quantity in self._lots:
                if remaining > 1:
                    continue
                pair = groups.setdefault(self._contract_key(option), [0, 0])
                pair[0 if quantity > 0 else 1] += abs(quantity)
            guaranteed = 100 * sum(min(long, short)
                                   for long, short in groups.values())
            self._today_cache = groups, guaranteed
        return self._today_cache

    def _guaranteed_today_cents(self):
        """Pathwise minimum credit before the checker's next cash test.

        For one binary event, L longs and S shorts pay L*X+S*(1-X), whose
        minimum over X in {0,1} is min(L,S).  Summing this lower bound over
        distinct events is valid even when their payoffs are correlated.
        """
        return self._today_groups()[1]

    def _hedge_credit_cents(self, option, sign, quantity):
        """Increase in today's guaranteed credit caused by this fill."""
        long, short = self._today_group(option)
        opposite_excess = max((short - long) if sign > 0 else
                              (long - short), 0)
        return 100 * min(max(int(quantity), 0), opposite_excess)

    @staticmethod
    def _loss_cents(price, sign, quantity):
        loss = price if sign > 0 else 1.0 - price
        # Prices are penny-valued by protocol.  Rounding the unit loss upward
        # also keeps the ledger conservative if a malformed sub-penny price is
        # ever delivered, while preserving linearity in executable quantity.
        unit_loss = max(0, math.ceil(loss * 100.0 - 1e-9))
        return quantity * unit_loss

    def _add_reservation(self, cents):
        self._reserved_cents += int(cents)
        self._reserved_cash = self._reserved_cents / 100.0

    def _release_reservation(self, cents):
        self._reserved_cents = max(self._reserved_cents - int(cents), 0)
        self._reserved_cash = self._reserved_cents / 100.0

    def _reservation_cents(self, option, price, sign, quantity):
        debit = self._loss_cents(price, sign, quantity)
        return max(debit - self._hedge_credit_cents(
            option, sign, quantity), 0)

    def _cash_quantity(self, price, sign, limit, option=None):
        """Largest size satisfying the exact next-day checker inequality."""
        cap = max(int(limit), 0)
        unit_debit = self._loss_cents(price, sign, 1)
        if unit_debit == 0:
            return cap
        slack = self._free_cents()
        hedge = 0
        if option is not None:
            long, short = self._today_group(option)
            hedge = max((short - long) if sign > 0 else
                        (long - short), 0)
        if cap <= hedge:
            return cap
        # While offsetting an opposite lot, each contract creates a guaranteed
        # $1 credit and costs at most $1, so safety slack cannot fall.  Beyond
        # the hedge, every additional contract consumes its full checker debit.
        slack += hedge * (100 - unit_debit)
        return min(cap, hedge + slack // unit_debit)

    def _current_values(self):
        return {u.underlying_id: u.value for u in self.underlying_state}

    def _relevant_values(self, option):
        values = self._current_values()
        ids = {leg.underlying_id for leg in option.legs}
        if option.steps_until_expiry and ids != {FED_FUNDS_RATE_UNDERLYING_ID}:
            ids.add(FED_FUNDS_RATE_UNDERLYING_ID)
        return tuple(sorted((uid, values[uid]) for uid in ids))

    @staticmethod
    def _validate(values, option):
        supported = {FED_FUNDS_RATE_UNDERLYING_ID, AJARAI_UNDERLYING_ID,
                     THERIODIC_UNDERLYING_ID}
        ids = {leg.underlying_id for leg in option.legs}
        if ids - supported:
            raise ValueError("Option contains an unsupported underlying")
        required = set(ids)
        if option.steps_until_expiry and ids != {FED_FUNDS_RATE_UNDERLYING_ID}:
            required.add(FED_FUNDS_RATE_UNDERLYING_ID)
        if required - values.keys():
            raise ValueError("Missing a required current underlying value")
        if option.steps_until_expiry and any(values[uid] <= 0 for uid in required if uid != FED_FUNDS_RATE_UNDERLYING_ID):
            raise ValueError("Company values must be positive")

    def _clear_caches(self):
        self._price_cache.clear()
        self._bound_cache.clear()
